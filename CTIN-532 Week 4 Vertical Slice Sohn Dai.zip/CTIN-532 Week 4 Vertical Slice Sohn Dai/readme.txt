readme.txt

Inputs:
Two Characters same actions mapped to different keys
	Left Character
		'A': Walk left & Use Left Hand
		'S': Speak
		'D': Walk Right & Use Right Hand
		'A + S + D': Crouch
		'Shift': Pick Up Action

	Right Character
		'J': Walk left & Use Left Hand
		'K': Speak
		'L': Walk Right & Use Right Hand
		'J + K + L': Crouch
		'Space': Pick Up Action

Sound Effects:
	Creative Commons from FreeSound
		InspectorJ
		hdfreema
		punpcklbw - crouch
		StateAardvark - Cockroach